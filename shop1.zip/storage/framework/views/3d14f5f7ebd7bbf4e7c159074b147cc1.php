

<?php $__env->startSection('title', isset($order) ? 'Chỉnh sửa đơn hàng' : 'Thêm đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="box-container">
        <header class="page-header">
            <h1 class="title-header"><?php echo e(isset($order) ? 'Sửa đơn hàng' : 'Thêm đơn hàng'); ?></h1>
            <ul class="button-header">
                <li><a class="uk-button uk-button-primary" href="javascript:void(0)"
                        onclick="javascript:jQuery(this).submitForm('save')">Lưu</a></li>
                <li><a class="uk-button uk-button-success" href="javascript:void(0)"
                        onclick="javascript:jQuery(this).submitForm('update')">Cập nhật</a></li>
                <li><a class="uk-button uk-button-danger" href="<?php echo e(url('/admin/orders')); ?>">Trở về</a>
                </li>
            </ul>
        </header>
        <div class="box-content">
            <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form class="uk-form uk-form-stacked" action="<?php echo e(url('admin/orders')); ?>" method="POST" name="adminForm"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="content">
                    <div class="uk-grid">
                        <h4>Chi tiết đơn hàng</h4>
                        <div class="uk-width-1-1">
                            <?php if(isset($order)): ?>
                                <p><strong>Mã đơn hàng:</strong> #<?php echo e(isset($order) ? $order->code_order : ''); ?></p>
                                <p><strong>Ngày tạo: </strong> <?php echo e(isset($order) ? $order->created : ''); ?></p>
                            <?php endif; ?>

                            <p><strong>Phương thức thanh toán: </strong>
                                <?php
                                    $payments = Config::get('app.order_payment_method');
                                ?>
                                <select name="payment" id="">
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"
                                            <?php echo e(isset($order) ? ($order->payment == $key ? 'selected' : '') : ''); ?>>
                                            <?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </p>
                            <p><strong>Trạng thái: </strong>
                                <?php
                                    $stated = Config::get('app.order_stated');
                                ?>
                                <select name="stated" id="">
                                    <?php $__currentLoopData = $stated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"
                                            <?php echo e(isset($order) ? ($order->stated == $key ? 'selected' : '') : ''); ?>>
                                            <?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </p>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="notes">Ghi chú</label>
                                <div class="uk-form-controls">
                                    <textarea class="uk-width-1-1" name="notes" id="" rows="3"><?php echo e(isset($order) ? $order->notes : ''); ?> </textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <h4>Thông tin khách hàng</h4>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-1-2">
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="buyer">Người mua</label>
                                <div class="uk-form-controls">
                                    <input type="text" class="uk-width-1-1" name="buyer" id="buyer"
                                        value="<?php echo e(isset($order) ? $order->buyer : ''); ?>">
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="phone">Số điện thoại</label>
                                <div class="uk-form-controls">
                                    <input type="number" class="uk-width-1-1" name="phone" id="phone"
                                        value="<?php echo e(isset($order) ? $order->phone : ''); ?>">
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="phone">Email</label>
                                <div class="uk-form-controls">
                                    <input type="email" class="uk-width-1-1" name="email" id="email"
                                        value="<?php echo e(isset($order) ? $order->email : ''); ?>">
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="customer_request">Yêu cầu của khách hàng</label>
                                <div class="uk-form-controls">
                                    <textarea class="uk-width-1-1" name="customer_request" id="" rows="3"><?php echo e(isset($order) ? $order->request : ''); ?> </textarea>
                                </div>
                            </div>
                        </div>
                        <div class="uk-width-1-2">
                            
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="province">Tỉnh/Thành phố</label>
                                <div class="uk-form-controls">
                                    <select class="uk-width-1-1" name="province" id="province">
                                        <option value="">Chọn tỉnh/thành phố</option>
                                        <?php if(isset($province)): ?>
                                            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e($item->id == $order->province_id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="district">Quận/Huyện</label>
                                <div class="uk-form-controls">
                                    <select class="uk-width-1-1" name="district" id="district">
                                        <option value="">Chọn quận/huyện</option>
                                        <?php if(isset($district)): ?>
                                            <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e($item->id == $order->district_id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="ward">Phường/Xã</label>
                                <div class="uk-form-controls">
                                    <select class="uk-width-1-1" name="ward" id="ward">
                                        <option value="">Chọn phường/xã</option>
                                        <?php if(isset($ward)): ?>
                                            <?php $__currentLoopData = $ward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e($item->id == $order->ward_id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="ward">Địa chỉ cụ thể</label>
                                <div class="uk-form-controls">
                                    <textarea class="uk-width-1-1" name="address" id="address" rows="3"><?php echo e(isset($order) ? $order->address : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-flex uk-panel">
                                <h2>Danh sách sản phẩm</h2>
                                <button type="button" class="add-product uk-button uk-button-primary">Thêm sản
                                    phẩm</button>
                            </div>
                            <table style="<?php echo e(count($listProduct) > 0 ? '' : 'display:none;'); ?>"
                                class="uk-table list-product-order">
                                <thead>
                                    <th>
                                        Hình sản phẩm
                                    </th>
                                    <th>
                                        Tên
                                    </th>
                                    <th>
                                        Giá
                                    </th>
                                    <th>
                                        Số lượng
                                    </th>
                                    <th>
                                        Tổng giá
                                    </th>
                                    <th>
                                        Màu
                                    </th>
                                    <th>
                                        Size
                                    </th>
                                    <th>
                                        Hành động
                                    </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $product = App\Models\Product::find($item->product_id);
                                        ?>
                                        <tr class="data-order-item" <?php echo e(isset($item->id) ? 'data-id=' . $item->id : ''); ?>

                                            data-product_id="<?php echo e($product->id); ?>"
                                            data-product_name="<?php echo e($product->name); ?>"
                                            data-product_qty="<?php echo e($item->product_qty); ?>"
                                            data-product_price="<?php echo e($product->sale_price); ?>"
                                            data-product_color="<?php echo e($item->product_color); ?>"
                                            data-product_size="<?php echo e($item->product_size); ?>">
                                            <td>
                                                <img style="width:80px; height:80px"
                                                    src="<?php echo e(asset($product->thumbnail)); ?>" alt="Not found">
                                            </td>
                                            <td>
                                                <?php echo e($product->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($product->sale_price); ?>

                                            </td>
                                            <td>
                                                <div class="item-detail">
                                                    <?php echo e($item->product_qty); ?>

                                                </div>
                                                <div class="item-edit">
                                                    <button type="button" class="uk-button quantity-decrese">-</button>
                                                    <input type="number" class="input-quantity"
                                                        value="<?php echo e($item->product_qty); ?>">
                                                    <button type="button" class="uk-button quantity-increse">+</button>
                                                </div>

                                            </td>
                                            <td class="total-price">
                                                <?php echo e($product->sale_price * $item->product_qty); ?>

                                            </td>
                                            <td>
                                                <div class="item-detail"><?php echo e($item->product_color); ?></div>
                                                <div class="item-edit">
                                                    <select name="" class="order_item_color">
                                                        <?php $__currentLoopData = json_decode($product->product_colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                <?php echo e($item_color == $item->product_color ? 'selected' : ''); ?>>
                                                                <?php echo e($item_color); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="item-detail"><?php echo e($item->product_size); ?></div>
                                                <div class="item-edit">
                                                    <select name="" class="order_item_size">
                                                        <?php $__currentLoopData = json_decode($product->product_sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                <?php echo e($item_size == $item->product_size ? 'selected' : ''); ?>>
                                                                <?php echo e($item_size); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <button type="button" class="uk-button delete-product">&#x2715;</button>
                                                <button type="button" class="uk-button edit-product"><i
                                                        class="uk-icon-edit"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="no-product-text">
                                        <h4>Chưa có sản phẩm nào được thêm</h4>
                                    </div>
                                </tbody>
                            </table>
                            <div style="<?php echo e(count($listProduct) > 0 ? '' : 'display:none;'); ?>"
                                class="total-container uk-text-right">
                                <p class="total-all-product"><strong>Tổng tiền hàng : </strong><span></span></p>
                                <p class="ship"><strong>Phí vận chuyển : </strong><span>30000</span></p>
                                <p class="total-pay"><strong>Tổng thanh toán : </strong><span></span></p>
                            </div>

                        </div>
                        <br>

                    </div>
                </div>


        </div>
        <input type="hidden" name="list_order_item" class="list-order-item" value="">
        <input type="hidden" name="order_id" value="<?php echo e(isset($order) ? $order->id : 0); ?>">
        </form>
        <div class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Thêm sản phẩm</h2>
                <div class="uk-grid">
                    <div class="page-search uk-form">
                        <input class="" type="search" name="search" id="search"
                            placeholder="Tìm kiếm sản phẩm..." value="">
                        <button id="btnSearchProduct" class="uk-button">
                            <i class="uk-icon-search"></i>
                        </button>
                    </div>
                </div>
                <table class="uk-table uk-table-hover uk-form product-table ">
                    <thead>
                        <tr>
                            <th><input class="select-all" type="checkbox" id="select-all-product"></th>
                            <th>Hình ảnh</th>
                            <th>Tên sản phẩm</th>
                            <th>Giá sản phẩm</th>
                            <th>Giá bán</th>
                            <th>Màu</th>
                            <th>Size</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <button class="uk-button" type="button" id="prevPage">&#11164;</button>
                <span id="product-pagination">
                </span>
                <button class="uk-button" type="button" id="nextPage">&#11166;</button>
                <div>
                    <button class="uk-button uk-button-primary" id="addProduct">Thêm</button>
                </div>
            </div>

        </div>
    </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('backend/assets/order.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/orders/form.blade.php ENDPATH**/ ?>