
<?php $__env->startSection('title', isset($page) ? 'Sửa trang' : 'Thêm trang'); ?>
<?php $__env->startSection('content'); ?> 
<div class="box-container">
    <header class="page-header">
        <h1 class="title-header"><?php echo e(isset($page) ? 'Sửa trang' : 'Thêm trang'); ?></h1>
        <ul class="button-header">
            <li><a class="uk-button uk-button-primary" href="javascript:void(0)"
                    onclick="javascript:jQuery(this).submitForm('save')">Lưu</a></li>
            <li><a class="uk-button uk-button-success" href="javascript:void(0)"
                    onclick="javascript:jQuery(this).submitForm('update')">Cập nhật</a></li>
            <li><a class="uk-button uk-button-danger" href="<?php echo e(url('/admin/pages')); ?>">Trở về</a>
            </li>
        </ul>
    </header>
    <div class="box-content">
        <form class="uk-form uk-form-stacked" action="<?php echo e(url('admin/pages')); ?>" name="adminForm"
                method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content">
                    <div class="uk-grid">
                        <div class="uk-width-1-3">
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="title">Tiêu đề</label>
                                <div class="uk-form-controls">
                                    <input class="uk-width-1-1" type="text" id="title" name="title"
                                        value="<?php echo e(isset($page) ? $page->title : ''); ?>" />
                                </div>
                            </div>
                        </div>
                        <div class="uk-width-1-3">
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="title">Slug</label>
                                <div class="uk-form-controls">
                                    <input class="uk-width-1-1" type="text" id="" name=""
                                        value="<?php echo e(isset($page) ? $page->slug : ''); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-form-row">
                                <label class="uk-form-label" for="content">Nội dung chi tiết</label>
                                <div class="uk-form-controls">
                                    <textarea class="uk-width-1-1" id="description" name="content" rows="10"><?php echo e(isset($page) ? $page->content : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="id" value="<?php echo e(isset($page) ? $page->id : 0); ?>">
                <input type="hidden" name="action">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/pages/form.blade.php ENDPATH**/ ?>