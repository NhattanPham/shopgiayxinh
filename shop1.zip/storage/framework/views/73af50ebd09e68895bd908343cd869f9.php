<ul class="uk-pagination">
    <li>
        <a href="<?php echo e($paginator->url(1)); ?>">
            <i class="uk-icon-angle-double-left"></i>
        </a>
    </li>
    <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
        <?php if($paginator->currentPage() == $i): ?>
            <li class="uk-active"><span><?php echo e($i); ?></span></li>
        <?php else: ?>
            <li><a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
        <?php endif; ?>
    <?php endfor; ?>
    <li>
        <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>">
            <i class="uk-icon-angle-double-right"></i>
        </a>
    </li>
</ul><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/partials/pagination.blade.php ENDPATH**/ ?>