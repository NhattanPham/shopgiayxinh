
<?php $__env->startSection('option_content'); ?>
    <div class="list-order">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-item">
                <div class="uk-flex uk-flex-space-between">
                    <div>Ngày đặt hàng: <?php echo e($order->created); ?></div>
                    <div class="uk-text-right">
                        <span class="uk-text-success"><i class="uk-icon-plane"></i>
                            <?php echo e(Config::get('app.order_stated')[$order->stated]); ?></span> &emsp;
                        <a href="">LIÊN HỆ NGƯỜI BÁN</a>
                    </div>
                </div>
                <hr>
                <?php
                    $order_item = $order->getOrderItem($order->id);
                    $total_price = 0;
                ?>
                <?php $__currentLoopData = $order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="uk-flex uk-flex-space-between uk-flex-middle">
                        <?php
                            $image = App\Models\Product::select('thumbnail')
                                ->where('id', $item->product_id)
                                ->first();
                            $total_price += $item->product_qty * $item->product_price;
                            // dd($thumbnail->thumbnail);
                        ?>
                        <div class="uk-flex">
                            <div class="product-image">
                                <img style="width:80px; height:80px" src="<?php echo e(asset($image->thumbnail)); ?>" alt="Not Found">
                            </div>
                            <div>
                                <?php echo e($item->product_name . ' - ' . $item->product_color . ' - ' . $item->product_size); ?> <br>
                                <?php echo e(' x ' . $item->product_qty); ?>

                            </div>
                        </div>
                        <div>
                            <span class="uk-text-danger"><?php echo e($item->product_qty * $item->product_price); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <div class="uk-text-right">Thành tiền: <span class="uk-text-danger"><?php echo e($total_price); ?></span></div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/user/purchase.blade.php ENDPATH**/ ?>