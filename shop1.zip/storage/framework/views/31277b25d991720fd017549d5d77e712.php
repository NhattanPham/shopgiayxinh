
<?php $__env->startSection('title', 'Quản lý trang'); ?>
<?php $__env->startSection('content'); ?>
<div class="box-container">
    <header class="page-header">
        <h1 class="title-header">Danh sách trang</h1>
        <ul class="button-header">
            <li><a class="uk-button uk-button-success" href="<?php echo e(url('/admin/pages/create')); ?>">Thêm
                    mới</a></li>
        </ul>
    </header>
    <div class="box-content">
        <form action="" class="uk-form" name="adminList" method="GET">
            <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="toolbar">
                <div class="action-toolbar">
                    <select name="action">
                        <option value="">Chọn hành động</option>
                        <option value="published">Xuất bản</option>
                        <option value="unpublished">Không xuất bản</option>
                        <option value="delete">Xóa trang</option>
                    </select>
                    <button class="uk-button" type="button"
                        onclick="javascript:jQuery(this).submitList('changeAction')">Áp dụng</button>
                </div>
                <div class="filter-toolbar">
                    <div class="search-toolbar">
                        <input type="search" name="search"
                            value="<?php echo e(request()->input('search') ? request()->input('search') : ''); ?>"
                            placeholder="Tìm kiếm..." />
                        <button class="uk-button" type="button"
                            onclick="javascript:jQuery(this).submitList('search')"><i
                                class="uk-icon-search"></i></button>
                        <button class="uk-button" type="button" onclick="clean('<?php echo e(url('admin/pages')); ?>')">Làm
                            sạch</button>
                    </div>
                    <?php $limit_option = option('limit_pages'); ?>
                    <select class="numberPage"
                        onchange="javascript:jQuery(this).changeNumbePage('/admin/config/limited/' + this.value+'/limit_pages')">
                        <?php $__currentLoopData = Config::get('app.limited'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_limit => $value_limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key_limit); ?>" <?php echo e($key_limit == $limit_option ? 'selected' : ''); ?>>
                                <?php echo e($value_limit); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="content">
                <?php if(count($pages) > 0): ?>
                        <div class="uk-overflow-container">
                            <table class="uk-table">
                                <thead>
                                    <tr>
                                        <th><input class="select-all" type="checkbox" /></th>
                                        <th>Tiêu đề</th>
                                        <th>Slug</th>
                                        <th>Ngày tạo</th>
                                        <th>Ngày sửa</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" /></td>
                                            <td>
                                                <a href="<?php echo e(url('admin/pages/edit/' . $item->id)); ?>"><?php echo e($item->title); ?></a>
                                            </td>
                                            <td><?php echo e($item->slug); ?></td>
                                            <td><?php echo e(date_format(date_create($item->created), 'd/m/Y')); ?></td>
                                            <td><?php echo e(date_format(date_create($item->modified), 'd/m/Y')); ?></td>
                                            <td>
                                                <?php if($item->stated == 0): ?>
                                                    <a class="stated-off"
                                                        href="<?php echo e(url('/admin/menu/published/' . $item->id)); ?>">
                                                        <i class="uk-icon-toggle-off"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <a class="stated-on"
                                                        href="<?php echo e(url('/admin/menu/published/' . $item->id)); ?>">
                                                        <i class="uk-icon-toggle-on"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination">
                            <?php echo $__env->make('backend.partials.pagination', ['paginator' => $pages], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
            </div>
            <input type="hidden" name="task">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/pages/list.blade.php ENDPATH**/ ?>