

<?php $__env->startSection('content'); ?>
    <div class="home-product">
        <div class="container">
            <div class="uk-overflow-container">
                <?php if($carts != null): ?>
                <table class="uk-table">
                    <thead>
                        <tr>
                            <th>Hình</th>
                            <th>Tên sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Tổng tiền</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $product = App\Models\Product::find($cart->product_id);
                        ?>
                        <tr>
                            <td>
                                <img style="width: 80px; height:80px" src="<?php echo e(asset($product->thumbnail)); ?>" alt="Not found">
                            </td>
                            <td class="uk-text-middle">
                                <?php echo e($product->name); ?> <br>
                                <?php echo e($cart->color); ?>, <?php echo e($cart->size); ?>

                            </td>
                            <td class="uk-text-middle">
                                <span class="product-price">
                                    <?php echo e(number_format($product->sale_price, 0, ',', '.')); ?>

                                </span> đ
                            </td>
                            <td class="uk-text-middle">
                                <div class="quantity">
                                    <button class="uk-button decrease">-</button>
                                    <input type="number" class="input-quantity" value="<?php echo e($cart->quantity); ?>">
                                    <button class="uk-button increase">+</button>
                                </div>
                            </td>
                            <td class="uk-text-middle">
                                <span class="total-price">
                                    <?php echo e(number_format($product->sale_price * $cart->quantity, 0, ',', '.')); ?>

                                </span> đ
                            </td>
                            <td class="uk-text-middle">
                                <form action="<?php echo e(url('cart')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="uk-button"><i class="uk-icon-close"></i></button>
                                    <input type="hidden" name="product_id" value="<?php echo e($cart->product_id); ?>">
                                    <input type="hidden" name="color" value="<?php echo e($cart->color); ?>">
                                    <input type="hidden" name="size" value="<?php echo e($cart->size); ?>">
                                </form>
                            </td>
                            <input type="hidden" class="product_id" value="<?php echo e($cart->product_id); ?>">
                            <input type="hidden" class="color" value="<?php echo e($cart->color); ?>">
                            <input type="hidden" class="size" value="<?php echo e($cart->size); ?>">
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="order">
                    Tổng tiền hàng: <span id="total"></span> đ<br>
                    <a style="margin-top:20px;" class="uk-button button-buy" href="<?php echo e(url('/checkout')); ?>">Mua hàng</a>
                </div>
                <?php else: ?>
                    <h3>Giỏ hàng trống</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                updateTotalPrice();
                var increaseButtons = document.querySelectorAll('.increase');
                var decreaseButtons = document.querySelectorAll('.decrease');
                var inputQuantitys = document.querySelectorAll('.input-quantity');

                // Duyệt qua tất cả các nút tăng và thêm sự kiện click
                increaseButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        updateQuantity(button, 1);
                    });
                });

                // Duyệt qua tất cả các nút giảm và thêm sự kiện click
                decreaseButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        updateQuantity(button, -1);
                    });
                });
                //Duyệt qua tất cả các input và thêm sự kiện onchange
                inputQuantitys.forEach(function(input) {
                    input.addEventListener('change', function() {
                        // Lấy đối tượng hàng chứa sản phẩm
                        var row = this.closest('tr');
                        // Lấy giá sản phẩm từ span.product-price
                        var price = parseFloat(row.querySelector('.product-price').textContent.split(
                            '.').join(''));
                        var quantity = this.value;
                        if (quantity < 1)
                            return;
                        // Tính toán tổng giá tiền mới
                        var newTotalPrice = price * quantity;

                        // Cập nhật tổng giá tiền trong span.total-price
                        row.querySelector('.total-price').textContent = newTotalPrice.toLocaleString(
                            'it-IT');
                        updateTotalPrice();
                        var token = '<?php echo e(csrf_token()); ?>';
                        var formData = new FormData();
                        var product_id = row.querySelector('.product_id').value;
                        var color = row.querySelector('.color').value;
                        var size = row.querySelector('.size').value;
                        console.log(product_id, color, size);
                        formData.append('product_id', product_id);
                        formData.append('color', color);
                        formData.append('size', size);
                        formData.append('quantity', quantity);
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo e(url("/cart/updateQuantity")); ?>',
                            data: formData,
                            headers: {
                                'X-CSRF-TOKEN': token
                            },
                            success: function(response) {
                                console.log(response.success, response.data);
                            },
                            error: function(error) {
                                console.log(error.responseJSON);
                            },
                            cache: false,
                            contentType: false,
                            processData: false
                        });
                    })
                });

                function updateQuantity(button, change) {
                    // Lấy đối tượng hàng chứa sản phẩm
                    var row = button.closest('tr');
                    // Lấy giá sản phẩm từ span.product-price
                    var price = parseFloat(row.querySelector('.product-price').textContent.split('.').join(''));
                    // Lấy số lượng hiện tại từ input.input-quantity
                    var quantityInput = row.querySelector('.input-quantity');
                    var currentQuantity = parseInt(quantityInput.value);

                    // Tính toán số lượng mới
                    var newQuantity = currentQuantity + change;

                    // Đảm bảo số lượng không nhỏ hơn 1
                    if (newQuantity < 1) {
                        return;
                    }

                    // Cập nhật số lượng trong input.input-quantity
                    quantityInput.value = newQuantity;

                    // Tính toán tổng giá tiền mới
                    var newTotalPrice = price * newQuantity;

                    // Cập nhật tổng giá tiền trong span.total-price
                    row.querySelector('.total-price').textContent = newTotalPrice.toLocaleString('it-IT');

                    // Tính toán tổng giá tiền của tất cả các sản phẩm và cập nhật giá trị này trên giao diện
                    updateTotalPrice();
                    var token = '<?php echo e(csrf_token()); ?>';
                    var formData = new FormData();
                    var product_id = row.querySelector('.product_id').value;
                    var color = row.querySelector('.color').value;
                    var size = row.querySelector('.size').value;
                    console.log(product_id, color, size);
                    formData.append('product_id', product_id);
                    formData.append('color', color);
                    formData.append('size', size);
                    formData.append('quantity', newQuantity);
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(url('/cart/updateQuantity')); ?>',
                        data: formData,
                        headers: {
                            'X-CSRF-TOKEN': token
                        },
                        success: function(response) {
                            console.log(response.success, response.data);
                        },
                        error: function(error) {
                            console.log(error.responseJSON);
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });

                }
                // Cập nhật tổng tiền
                function updateTotalPrice() {
                    var total = 0;
                    var totalPriceElements = document.querySelectorAll('.total-price');
                    totalPriceElements.forEach(function(element) {
                        total += parseFloat(element.textContent.split('.').join(''));
                    });
                    document.getElementById('total').textContent = total.toLocaleString('it-IT');
                }

            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/cart/show.blade.php ENDPATH**/ ?>