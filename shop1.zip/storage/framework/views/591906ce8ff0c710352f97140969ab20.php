
<?php $__env->startSection('title','Quản lý Thành viên'); ?>
<?php $__env->startSection('content'); ?>
    <div class="box-container">
        <header class="page-header">
            <h1 class="title-header">Danh sách thành viên</h1>
            <ul class="button-header">
                <li><a class="uk-button uk-button-success" href="<?php echo e(url('/admin/users/create')); ?>">Thêm mới</a></li>
            </ul>
        </header>
        <div class="box-content">
            <form action="" class="uk-form" name="adminList" method="GET">
                <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="toolbar">
                    <div class="action-toolbar">
                        <select name="action">
                            <option value="">Chọn hành động</option>
                            <option value="activated">Kích hoạt</option>
                            <option value="blocked">Khóa tài khoản</option>
                            <option value="unlocked">Mở khóa</option>
                            <option value="delete">Xóa thành viên</option>
                        </select>
                        <button class="uk-button" type="button" onclick="javascript:jQuery(this).submitList('changeAction')">Áp dụng</button>
                    </div>
                    <div class="filter-toolbar">
                        <div class="search-toolbar">
                            <input type="search" name="search" value="<?php echo e(request()->input('search') ? request()->input('search') : ''); ?>" placeholder="Tìm kiếm..." />
                            <button class="uk-button" type="button" onclick="javascript:jQuery(this).submitList('search')"><i class="uk-icon-search"></i></button>
                            <select name="user_group" onchange="javascript:jQuery(this).submitList('user_group')">
                                <option value="">Chọn nhóm thành viên</option>
                                <?php $__currentLoopData = Config::get('auth.group_users'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_key => $group_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($group_key); ?>" <?php echo e((request()->input('user_group') == $group_key) ? 'selected' : ''); ?> ><?php echo e($group_value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="uk-button" type="button" onclick="clean('<?php echo e(url('admin/users')); ?>')">Làm sạch</button>
                        </div>
                        <?php $limit_option = option('limit_users'); ?>
                        <select class="numberPage" onchange="javascript:jQuery(this).changeNumbePage('/admin/config/limited/' + this.value+'/limit_users')">
                            <?php $__currentLoopData = Config::get('app.limited'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_limit => $value_limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key_limit); ?>" <?php echo e(($key_limit == $limit_option) ? 'selected' : ''); ?>><?php echo e($value_limit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="content">
                    <?php if(count($users) > 0): ?>
                    <div class="uk-overflow-container">
                        <table class="uk-table">
                            <thead>
                                <tr>
                                    <th><input class="select-all" type="checkbox" /></th>
                                    <th>Họ tên</th>
                                    <th>Điện thoại</th>
                                    <th>Email</th>
                                    <th>Nhóm</th>
                                    <th>Kích hoạt</th>
                                    <th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input type="checkbox" name="ids[]" value="<?php echo e($user->id); ?>" /></td>
                                    <td><a href="<?php echo e(url('/admin/users/edit/' . $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e(group_user($user->group)); ?></td>
                                    <td><?php echo e(($user->activated == 'Y') ? 'Có' : 'Chưa'); ?></td>
                                    <td>
                                        <?php if($user->blocked == 'Y'): ?>
                                        <a class="stated-off" href="<?php echo e(url('/admin/users/blocked/' . $user->id)); ?>">
                                            <i class="uk-icon-toggle-off"></i>
                                        </a>
                                        <?php else: ?>
                                        <a class="stated-on" href="<?php echo e(url('/admin/users/blocked/' . $user->id)); ?>">
                                            <i class="uk-icon-toggle-on"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination">
                        <?php echo $__env->make('backend.partials.pagination', ['paginator' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <input type="hidden" name="task">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/user/list.blade.php ENDPATH**/ ?>