

<?php $__env->startSection('title','File'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-box">
        <div class="wrapper-box">
           <iframe style="width: 100%;height: 800px" src="<?php echo e(url('admin/laravel-filemanager')); ?>" frameborder="0"></iframe>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/media/list.blade.php ENDPATH**/ ?>