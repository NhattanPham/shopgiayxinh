<div class="pagination-product">
    <?php if($data->lastPage() > 1): ?>
        <ul class="pagination-list">
            
            <?php if($data->onFirstPage()): ?>
                <li class="disabled"><span>&laquo;</span></li>
                <li class="disabled"><span>&#8249;</span></li>
            <?php else: ?>
                <li><a href="<?php echo e($data->url(1)); ?>" rel="prev">&laquo;</a></li>
                <li><a href="<?php echo e($data->previousPageUrl()); ?>" rel="prev">&#8249;</a></li>
            <?php endif; ?>

            

            <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                <?php if($i == $data->currentPage()): ?>
                    <li class="active"><span><?php echo e($i); ?></span></li>
                <?php elseif($i >= $data->currentPage() - 2 && $i <= $data->currentPage() + 2): ?>
                    <li><a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a></li>
                <?php elseif($i == $data->currentPage() - 3 || $i == $data->currentPage() + 3): ?>
                    <li class="disabled"><span>&hellip;</span></li>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if($data->hasMorePages()): ?>
                <li><a href="<?php echo e($data->nextPageUrl()); ?>" rel="next">&#8250;</a></li>
                <li><a href="<?php echo e($data->url($data->lastPage())); ?>" rel="next">&raquo;</a></li>
            <?php else: ?>
                <li class="disabled"><span>&#8250;</span></li>
                <li class="disabled"><span>&raquo;</span></li>
            <?php endif; ?>

        </ul>
    <?php endif; ?>
</div>
<?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/partials/custom-pagination.blade.php ENDPATH**/ ?>