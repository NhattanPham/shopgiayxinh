
<?php $__env->startSection('title', 'Quản lý slider'); ?>
<?php $__env->startSection('content'); ?>
    <div class="box-container">
        <form action="<?php echo e(url('admin/sliders/updateIndex')); ?>" class="uk-form" name="adminList" method="POST">
            <?php echo csrf_field(); ?>
        <header class="page-header">
            <h1 class="title-header">Danh sách slider</h1>
            <ul class="button-header">
                <li><button class="uk-button uk-button-primary">Cập nhật
                    </button></li>
                <li><a class="uk-button uk-button-success" href="<?php echo e(url('/admin/sliders/create')); ?>">Thêm
                        mới</a></li>
            </ul>
        </header>
        <div class="box-content">
            
                <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-slider" id="item-slider" data-id="<?php echo e($slider->id); ?>">
                            <div class="item-slider-image">
                                <img src="<?php echo e(asset($slider->image)); ?>" alt="Not found">
                            </div>
                            <div class="item-slider-content">
                                <table style="width: 100%">
                                    <tr>
                                        <td><label for="title">Tiêu đề:</label></td>
                                        <td style="width: 90%"><input type="text" id="title"
                                               name="<?php echo e('title_'.$slider->id); ?>" value="<?php echo e($slider->title); ?>"></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><label for="url">Link:</label></td>
                                        <td style="width: 90%"><input type="text" id="url"
                                            name="<?php echo e('url_'.$slider->id); ?>" value="<?php echo e($slider->link); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td><label for="ordering">Thứ tự:</label></td>
                                        <td style="width: 90%"><input type="text" id="ordering"
                                            name="<?php echo e('order_'.$slider->id); ?>" value="<?php echo e($slider->ordering); ?>"></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="item-slider-option">
                                <a href="<?php echo e(url('admin/sliders/edit/' . $slider->id)); ?>">Chỉnh sửa</a>
                                <a style="margin-left: 20px" href="<?php echo e(url('admin/sliders/delete/' . $slider->id)); ?>">Xóa</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/sliders/list.blade.php ENDPATH**/ ?>