<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="uk-alert uk-alert-danger"><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="uk-alert uk-alert-success">
        <a href="" class="uk-alert-close uk-close"></a>
        <p><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div class="uk-alert uk-alert-warning">
        <a href="" class="uk-alert-close uk-close"></a>
        <p><?php echo e(session('warning')); ?></p>
    </div>
<?php endif; ?>
<?php if(session('danger')): ?>
    <div class="uk-alert uk-alert-danger">
        <a href="" class="uk-alert-close uk-close"></a>
        <p><?php echo e(session('danger')); ?></p>
    </div>
<?php endif; ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/partials/message.blade.php ENDPATH**/ ?>