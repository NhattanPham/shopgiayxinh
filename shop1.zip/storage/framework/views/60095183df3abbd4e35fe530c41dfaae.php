
<?php $__env->startSection('content'); ?>
    <div class="container profile">
        <div class="uk-grid">
            <div class="uk-width-1-4">
                <div class="user-option">
                    <div class="avatar">
                    </div>
                    <div class="profile-link">
                        <a href="/profile" class="uk-flex uk-flex-middle">
                            <i class="uk-icon-user"></i>
                            Tài khoản của tôi
                        </a>
                    </div>
                    <div class="purchase-link ">
                        <a href="/purchase">
                            <i class="uk-icon-clipboard"></i> Đơn mua
                        </a>
                    </div>
                </div>
            </div>
            <div class="uk-width-3-4 info">
                <div class="uk-form uk-form-horizontal">
                    <div class="uk-form-row">
                        <h4>Hồ sơ của tôi</h4>
                        <p>Quản lý thông tin hồ sơ để bảo mật tài khoản</p>
                    </div>
                    <div class="uk-form-row">
                        <label class="uk-form-label uk-text-right" for="">Email Đăng Nhập </label>
                        <div class="uk-form-controls">
                            <input class="uk-width-3-5" type="text" name="email" value="<?php echo e(Auth::check() ? Auth()->user()->email : ''); ?>">
                        </div>
                    </div>
                    <div class="uk-form-row">
                        <label class="uk-form-label uk-text-right" for="name_user">Tên </label>
                        <div class="uk-form-controls">
                            <input class="uk-width-3-5" type="text" name="name_user" value="<?php echo e(Auth::check() ? Auth()->user()->name : ''); ?>">
                        </div>
                    </div>
                    <div class="uk-form-row">
                        <label class="uk-form-label uk-text-right" for="phone">Số điện thoại </label>
                        <div class="uk-form-controls">
                            <input class="uk-width-3-5" type="number" name="phone" value="<?php echo e(Auth::check() ? Auth()->user()->phone : ''); ?>">
                        </div>
                    </div>
                    <div class="uk-form-row">
                        <label class="uk-form-label uk-text-right" for="gender">Giới tính </label>
                        <div class="uk-form-controls uk-flex uk-flex-middle list-gender">
                            <input type="radio" name="gender" value="1">Nam
                            <input type="radio" name="gender" value="2">Nữ
                            <input type="radio" name="gender" value="0">Khác
                        </div>
                    </div>
                    <div class="uk-form-row">
                        <label class="uk-form-label uk-text-right" for="">Ngày sinh</label>
                        <div class="uk-form-controls uk-flex uk-flex-middle list-gender">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/profile/show.blade.php ENDPATH**/ ?>