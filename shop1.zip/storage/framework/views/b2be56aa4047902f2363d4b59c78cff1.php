

<?php $__env->startSection('content'); ?>
    <div class="home-product">
        <div class="container">
            <div class="uk-overflow-container">
                <?php if($products != null ): ?>
                    <table class="uk-table">
                        <thead>
                            <tr>
                                <th>Hình</th>
                                <th>Tên sản phẩm</th>
                                <th>Giá</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img style="width: 80px; height:80px" src="<?php echo e(asset($product->thumbnail)); ?>"
                                        alt="Not found">
                                </td>
                                <td class="uk-text-middle">
                                    <?php echo e($product->name); ?>

                                </td>
                                <td class="uk-text-middle">
                                    <?php echo e($product->sale_price); ?>

                                </td>
                                <td class="uk-text-middle">
                                    <button class="uk-button">X</button>
                                    <button class="uk-button">Add to Cart</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php else: ?>
                    <h3>Không có sản phẩm yêu thích</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/wishlist/show.blade.php ENDPATH**/ ?>