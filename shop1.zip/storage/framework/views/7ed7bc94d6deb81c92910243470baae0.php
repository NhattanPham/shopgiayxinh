<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Xưởng Giày Dép</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/slick/slick.css')); ?>" />
    <link href="<?php echo e(asset('backend/assets/uikit/css/uikit.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/uikit/css/uikit.almost-flat.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/uikit/css/components/notify.almost-flat.min.css')); ?>">
    <link href="<?php echo e(asset('backend/assets/home.css')); ?>" rel="stylesheet">
</head>

<body>
    <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main-content">
        <?php echo $__env->yieldContent('content'); ?>

        <div class="home-product"></div>
        <div class="home-product"></div>
        <div class="home-blog"></div>
        <div class="home-process"></div>
    </main>
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('backend/assets/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/uikit/js/uikit.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/uikit/js/components/notify.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('backend/assets/home.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.sliders').slick({
                dots: false,
                arrows: false,
                infinite: true,
                speed: 500,
                fade: true,
                autoplay: true,
                autoplaySpeed: 2000,
                cssEase: 'linear'
            });

            $('.slider-home').slick({
                dots: false,
                infinite: true,
                speed: 1000,
                fade: true,
                autoplay: true,
                autoplaySpeed: 2500,
                cssEase: 'linear'
            });
            $('.home-best-slick').slick({
                dots: false,
                infinite: true,
                speed: 300,
                autoplay: true,
                autoplaySpeed: 2000,
                centerPadding: '30px',
                slidesToShow: 5,
                slidesToScroll: 1,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 4,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    }
                ]
            });

            $('.slick-blog-home').slick({
                infinite: true,
                lazyLoad: 'ondemand',
                slidesToShow: 3,
                slidesToScroll: 1,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    }
                ]
            });

            $('.logo-trademark-footer').slick({
                dots: false,
                infinite: true,
                speed: 300,
                autoplay: true,
                autoplaySpeed: 2000,
                centerPadding: '30px',
                slidesToShow: 8,
                slidesToScroll: 1,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
            $('.image-detail').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                fade: true,
                asNavFor: '.list-image-detail'
            });
            $('.list-image-detail').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                arrows: true,
                asNavFor: '.image-detail',
                // dots: true,
                centerMode: true,
                focusOnSelect: true
            });
        });
    </script>
</body>

</html>
<?php /**PATH D:\phpProject\shopgiayxinh\resources\views/welcome.blade.php ENDPATH**/ ?>