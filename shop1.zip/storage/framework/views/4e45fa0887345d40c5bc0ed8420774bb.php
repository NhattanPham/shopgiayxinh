
<?php $__env->startSection('title', 'Quản lý Danh mục'); ?>
<?php $__env->startSection('content'); ?>
    <div class="box-container">
        <header class="page-header">
            <h1 class="title-header">Danh sách danh mục</h1>
            <ul class="button-header">
                <li><a class="uk-button uk-button-primary" href="">Lưu</a></li>
                <li><a class="uk-button uk-button-success" href="">Cập nhật</a></li>
                <li><a class="uk-button uk-button-danger" href="<?php echo e(url('/admin/categories/' . $extension . '/create')); ?>">Thêm
                        mới</a></li>
            </ul>
        </header>
        <div class="box-content">
            <form action="" class="uk-form" name="adminList" method="GET">
                <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="toolbar">
                    <div class="action-toolbar">
                        <select name="action">
                            <option value="">Chọn hành động</option>
                            <option value="delete">Xóa danh mục</option>
                        </select>
                        <button class="uk-button" type="button"
                            onclick="javascript:jQuery(this).submitList('changeAction')">Áp dụng</button>
                    </div>
                    <div class="filter-toolbar">
                        <div class="search-toolbar">
                            <input type="search" name="search"
                                value="<?php echo e(request()->input('search') ? request()->input('search') : ''); ?>"
                                placeholder="Tìm kiếm..." />
                            <button class="uk-button" type="button"
                                onclick="javascript:jQuery(this).submitList('search')"><i
                                    class="uk-icon-search"></i></button>
                            <button class="uk-button" type="button" onclick="clean('<?php echo e(url('admin/users')); ?>')">Làm
                                sạch</button>
                        </div>
                        <?php $limit_option = option('limit_categories'); ?>
                        <select class="numberPage" onchange="javascript:jQuery(this).changeNumbePage('/shopgiayxinh/admin/config/limited/' + this.value+'/limit_categories')">
                            <?php $__currentLoopData = Config::get('app.limited'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_limit => $value_limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key_limit); ?>" <?php echo e($key_limit == $limit_option ? 'selected' : ''); ?>>
                                    <?php echo e($value_limit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="content">
                    <?php if(count($categories) > 0): ?>
                        <div class="uk-overflow-container">
                            <table class="uk-table">
                                <thead>
                                    <tr>
                                        <th><input class="select-all" type="checkbox" /></th>
                                        <th>Tên</th>
                                        <th>Lượt xem</th>
                                        <th>Ngày tạo</th>
                                        <th>Ngày sửa</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" name="ids[]" value="<?php echo e($category->id); ?>" /></td>
                                            <td><?php echo e(tab_level($category)); ?><a
                                                    href="<?php echo e(url('admin/categories/' . $extension . '/edit/' . $category->id)); ?>"><?php echo e($category->name); ?></a><br>
                                                    <small>Slug: <?php echo e($category->slug); ?></small>
                                                </td>
                                            <td>0</td>
                                            <td><?php echo e(date_format(date_create($category->created), 'd/m/Y')); ?></td>
                                            <td><?php echo e(date_format(date_create($category->modified), 'd/m/Y')); ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination">
                            <?php echo $__env->make('backend.partials.pagination', ['paginator' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/categories/show.blade.php ENDPATH**/ ?>