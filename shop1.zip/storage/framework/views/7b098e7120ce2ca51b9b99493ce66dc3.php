
<?php $__env->startSection('title', 'Quản lý sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
<div class="box-container">
    <header class="page-header">
        <h1 class="title-header">Danh sách sản phẩm</h1>
        <ul class="button-header">
            <li><a class="uk-button uk-button-success" href="<?php echo e(url('/admin/products/create')); ?>">Thêm
                    mới</a></li>
        </ul>
    </header>
    <div class="box-content">
        <form action="" class="uk-form" name="adminList" method="GET">
            <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="toolbar">
                <div class="action-toolbar">
                    <select name="action">
                        <option value="">Chọn hành động</option>
                        <option value="published">Xuất bản</option>
                        <option value="unpublished">Không xuất bản</option>
                        <option value="delete">Xóa sản phẩm</option>
                    </select>
                    <button class="uk-button" type="button"
                        onclick="javascript:jQuery(this).submitList('changeAction')">Áp dụng</button>
                </div>
                <div class="filter-toolbar">
                    <div class="search-toolbar">
                        <input type="search" name="search"
                            value="<?php echo e(request()->input('search') ? request()->input('search') : ''); ?>"
                            placeholder="Tìm kiếm..." />
                        <button class="uk-button" type="button"
                            onclick="javascript:jQuery(this).submitList('search')"><i
                                class="uk-icon-search"></i></button>
                        <button class="uk-button" type="button" onclick="clean('<?php echo e(url('admin/products')); ?>')">Làm
                            sạch</button>
                    </div>
                    <?php $limit_option = option('limit_products'); ?>
                    <select class="numberPage"
                        onchange="javascript:jQuery(this).changeNumbePage('/admin/config/limited/' + this.value+'/limit_products')">
                        <?php $__currentLoopData = Config::get('app.limited'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_limit => $value_limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key_limit); ?>" <?php echo e($key_limit == $limit_option ? 'selected' : ''); ?>>
                                <?php echo e($value_limit); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="content">
                <?php if(count($products) > 0): ?>
                <div class="uk-overflow-container">
                    <table class="uk-table">
                        <thead>
                            <tr>
                                <th><input class="select-all" type="checkbox" /></th>
                                <th>Hình đại diện</th>
                                <th>Tên sản phẩm</th>
                                <th>Giá sản phẩm</th>
                                <th>Giá bán</th>
                                <th>Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="uk-text-middle"><input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" /></td>
                                    <td>
                                        <img style="width:80px; height:80px" src="<?php echo e(url($item->thumbnail)); ?>" alt="Not found">
                                    </td>
                                    <td class="uk-text-middle">
                                        <a href="<?php echo e(url('admin/products/edit/' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                                    </td>
                                    <td class="uk-text-middle"><?php echo e($item->product_price); ?></td>
                                    <td class="uk-text-middle"><?php echo e($item->sale_price); ?></td>
                                    <td class="uk-text-middle">
                                        <?php if($item->stated == 0): ?>
                                            <a class="stated-off"
                                                >
                                                <i class="uk-icon-toggle-off"></i>
                                            </a>
                                        <?php else: ?>
                                            <a class="stated-on"
                                               >
                                                <i class="uk-icon-toggle-on"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <?php echo $__env->make('backend.partials.pagination', ['paginator' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php endif; ?>
            </div>
            <input type="hidden" name="task">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/products/list.blade.php ENDPATH**/ ?>