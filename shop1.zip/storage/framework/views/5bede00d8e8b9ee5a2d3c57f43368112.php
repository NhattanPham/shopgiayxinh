
<?php $__env->startSection('content'); ?>
<div style="padding: 50px 0 250px 100px;">
    <h2>Trang không tồn tại</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/pageNotFound.blade.php ENDPATH**/ ?>