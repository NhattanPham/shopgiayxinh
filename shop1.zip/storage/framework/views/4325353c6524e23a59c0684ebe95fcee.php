
<?php $__env->startSection('title', 'Chi tiết đơn hàng'); ?>
<?php $__env->startSection('content'); ?>
    <div class="box-container">
        <header class="page-header">
            <h1 class="title-header">Chi tiết đơn hàng</h1>
            <ul class="button-header">
                <li><a class="uk-button uk-button-success" href="<?php echo e(url('admin/orders/edit/' . $order->id)); ?>">Chỉnh sửa</a>
                </li>
                <li><a class="uk-button uk-button-danger" href="<?php echo e(url('/admin/orders')); ?>">Trở về</a>
                </li>
            </ul>
        </header>
        <div class="box-content">
            <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
                <div class="uk-grid">
                    <div class="uk-width-2-3">
                        <div class="uk-flex uk-flex-space-between">
                            <div>
                                <strong>Mã đơn hàng : #<?php echo e(isset($order) ? $order->code_order : ''); ?></strong>
                                <p><strong>Ngày tạo : </strong><?php echo e(isset($order) ? $order->created : ''); ?></p>
                            </div>
                            <div class="order-stated">
                                <?php echo e(Config::get('app.order_stated')[$order->stated]); ?>

                            </div>
                        </div>
                        <div class="uk-grid">
                            <div class="uk-width-1-1 uk-form-row">
                                <hr>
                                <h4><strong>Thông tin khách hàng</strong></h4>
                            </div>
                        </div>
                        <div class="uk-grid">
                            
                            <div class="uk-width-1-2">
                                <div class="uk-form-row">
                                    <p><strong>Tên khách hàng :</strong> <?php echo e(isset($order) ? $order->buyer : ''); ?></p>
                                    <p><strong>Số điện thoại :</strong> <?php echo e(isset($order) ? $order->phone : ''); ?></p>
                                    <p><strong>Email :</strong> <?php echo e(isset($order) ? $order->email : ''); ?></p>
                                    <p><strong>Yêu cầu của khách hàng :</strong> <?php echo e(isset($order) ? $order->request : ''); ?>

                                    </p>
                                    <p><strong>Phương thức thanh toán: </strong>
                                        <?php echo e(Config::get('app.order_payment_method')[$order->payment]); ?></p>
                                </div>
                            </div>
                            <div class="uk-width-1-2">
                                <p><strong>Tỉnh/Thành phố :</strong> TP Hồ Chí Minh</p>
                                <p><strong>Quận/Huyện :</strong> Quận Thủ Đức</p>
                                <p><strong>Phường/Xã : </strong> Phường Hiệp Bình Phước</p>
                                <p><strong>Địa chỉ cụ thể : </strong> <?php echo e(isset($order) ? $order->address : ''); ?></p>
                            </div>
                        </div>
                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                                <hr>
                                <h4><strong>Danh sách sản phẩm</strong></h4>
                                <?php if(count($listProduct) > 0): ?>
                                    <table class="uk-table list-product-order">
                                        <thead>
                                            <th>
                                                Thông tin sản phẩm
                                            </th>
                                            <th class="uk-text-right">
                                                Giá
                                            </th>
                                            <th class="uk-text-right">
                                                Số lượng
                                            </th>
                                            <th class="uk-text-right">
                                                Tổng giá
                                            </th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $product = App\Models\Product::find($item->product_id);
                                                ?>
                                                <tr class="data-order-item"
                                                    <?php echo e(isset($item->id) ? 'data-id=' . $item->id : ''); ?>

                                                    data-product_id="<?php echo e($product->id); ?>"
                                                    data-product_name="<?php echo e($product->name); ?>" data-product_qty="1"
                                                    data-product_color="<?php echo e($item->product_color); ?>"
                                                    data-product_size="<?php echo e($item->product_size); ?>">
                                                    <td>
                                                        <div class="uk-flex">
                                                            <div>
                                                                <img style="width:80px; height:80px"
                                                                    src="<?php echo e(asset($product->thumbnail)); ?>" alt="Not found">
                                                            </div>
                                                            <div>
                                                                <?php echo e($product->name); ?><br>
                                                                <?php echo e($item->product_color); ?> - <?php echo e($item->product_size); ?>

                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="uk-text-right">
                                                        <?php echo e($product->sale_price); ?>

                                                    </td>
                                                    <td class="uk-text-right">
                                                        <?php echo e($item->product_qty); ?>

                                                    </td>
                                                    <td class="uk-text-right">
                                                        <?php echo e($product->sale_price * $item->product_qty); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="uk-text-right" colspan="3"><strong>Tổng tiền hàng</strong>
                                                </td>
                                                <td class="uk-text-right">1000000</td>
                                            </tr>
                                            <tr>
                                                <td class="uk-text-right" colspan="3"><strong>Phí vận chuyển</strong>
                                                </td>
                                                <td class="uk-text-right">30000</td>
                                            </tr>
                                            <tr>
                                                <td class="uk-text-right" colspan="3"><strong>Giảm giá</strong></td>
                                                <td class="uk-text-right">15%</td>
                                            </tr>
                                            <tr>
                                                <td class="uk-text-right" colspan="3"><strong>Tổng thanh toán</strong>
                                                </td>
                                                <td class="uk-text-right">12500000</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <h4>Chưa có sản phẩm nào được thêm</h4>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                    <div class="uk-width-1-3">
                        <div class="uk-form-row">
                            <label class="uk-form-label"><strong>Ghi chú:</strong></label>
                            <div class="uk-form-controls">
                                <?php echo e(isset($order) ? $order->notes : ''); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/orders/detail.blade.php ENDPATH**/ ?>