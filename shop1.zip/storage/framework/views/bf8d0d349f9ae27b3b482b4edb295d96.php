

<?php $__env->startSection('content'); ?>
    <div class="home-product">
        <div class="container">
            <?php
                echo html_entity_decode($blog->content);
            ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/blog/showBlogDetail.blade.php ENDPATH**/ ?>