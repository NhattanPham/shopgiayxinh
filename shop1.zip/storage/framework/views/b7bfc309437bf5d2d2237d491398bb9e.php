
<?php $__env->startSection('title','Trang quản trị'); ?>
<?php $__env->startSection('content'); ?>
    <h1>This is dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/dashboard/list.blade.php ENDPATH**/ ?>