    <ul class="menu-sidebar">
        <?php $__currentLoopData = Config::get('menuadmin'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyItem => $valueItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li <?php echo e(request()->is('*/' . $keyItem . '*') ? ' class="active"' : ''); ?>>
                <a href="<?php echo e(url('admin/' . $keyItem)); ?>">
                    <i class="<?php echo e($valueItem['icon']); ?>"></i>
                    <span class="link-name"><?php echo e($valueItem['name']); ?></span>
                </a>
                <?php if(isset($valueItem['sub-menu'])): ?>
                    <ul class="sub-menu">
                        <?php $__currentLoopData = $valueItem['sub-menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('admin/'.$key)); ?>"><?php echo e($value); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php /**PATH D:\phpProject\shopgiayxinh\resources\views/backend/partials/menu.blade.php ENDPATH**/ ?>