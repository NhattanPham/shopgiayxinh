

<?php $__env->startSection('content'); ?>
    <div class="home-product product-with-category">
        <div class="container">
            <h2><?php echo e($category->name); ?></h2>
            <div class="filter">
                <strong>Sắp xếp theo: </strong>
                <ul>
                    <li class="<?php echo e(request()->input('orderBy') == 'name ASC' ? 'active' : ''); ?>"><a
                            href="<?php echo e(url($slug . '?orderBy=name%20ASC')); ?>"><i
                                class="<?php echo e(request()->input('orderBy') == 'name ASC' ? 'uk-icon-dot-circle-o' : 'uk-icon-circle-o'); ?>"></i>
                            Tên A-Z</a></li>
                    <li class="<?php echo e(request()->input('orderBy') == 'name DESC' ? 'active' : ''); ?>"><a
                            href="<?php echo e(url($slug . '?orderBy=name%20DESC')); ?>"><i
                                class="<?php echo e(request()->input('orderBy') == 'name DESC' ? 'uk-icon-dot-circle-o' : 'uk-icon-circle-o'); ?>"></i>
                            Tên Z-A</a></li>
                    <li class="<?php echo e(request()->input('orderBy') == 'created DESC' ? 'active' : ''); ?>"><a
                            href="<?php echo e(url($slug . '?orderBy=created%20DESC')); ?>"><i
                                class="<?php echo e(request()->input('orderBy') == 'created DESC' ? 'uk-icon-dot-circle-o' : 'uk-icon-circle-o'); ?>"></i>
                            Mới nhất</a></li>
                    <li class="<?php echo e(request()->input('orderBy') == 'sale_price ASC' ? 'active' : ''); ?>"><a
                            href="<?php echo e(url($slug . '?orderBy=sale_price%20ASC')); ?>"><i
                                class="<?php echo e(request()->input('orderBy') == 'sale_price ASC' ? 'uk-icon-dot-circle-o' : 'uk-icon-circle-o'); ?>"></i>
                            Giá thấp đến cao</a></li>
                    <li class="<?php echo e(request()->input('orderBy') == 'sale_price DESC' ? 'active' : ''); ?>"><a
                            href="<?php echo e(url($slug . '?orderBy=sale_price%20DESC')); ?>"><i
                                class="<?php echo e(request()->input('orderBy') == 'sale_price DESC' ? 'uk-icon-dot-circle-o' : 'uk-icon-circle-o'); ?>"></i>
                            Giá cao đến thấp</a></li>
                </ul>
            </div>
            <div class="wrap-product">
                <ul class="grid-show-product">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <?php echo $__env->make('frontend.partials.itemProduct', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php echo e($products->appends(request()->all())->links('frontend.partials.custom-pagination', ['data' => $products])); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/product/showWithCategory.blade.php ENDPATH**/ ?>