

<?php $__env->startSection('content'); ?>
    <div class="home-slider">
        <div class="container">
            <div class="home-slider-row">
                <div class="slider-featured">
                    <div class="sliders">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img src="<?php echo e(asset($slider->image)); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="banner-featured">
                    <div class="item-banner">
                        <img src="<?php echo e(asset('uploads/sliders/bn1.webp')); ?>">
                    </div>
                    <div class="item-banner">
                        <img src="<?php echo e(asset('uploads/sliders/bn1.webp')); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="home-best">
        <div class="container">
            <div class="home-best-slick">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('frontend.partials.itemProduct', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <div class="home-product">
        <div class="container">
            <div class="wrap-product">
                <header class="header-home">
                    <h3 class="title-home">Giày dép nam</h3>
                    <ul class="menu-header">
                        <li><a href="">Giày tây công sở</a></li>
                        <li><a href="">Giày sneaker</a></li>
                        <li><a href="">Giày lười</a></li>
                        <li><a href="">Giày mọi</a></li>
                        <li><a href="">Giày tăng chiều cao</a></li>
                        <li><a href="">Dép nam</a></li>
                        <li><a href="">Giày boot</a></li>
                    </ul>
                    <a class="all-header" href="<?php echo e(url('giay-dep-nam')); ?>">Xem tất cả</a>
                </header>
                <ul class="list-product">
                    <?php $__currentLoopData = $products->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cate_slug = App\Models\Categories::find($product->cate_id)->slug;
                        ?>
                        <li class="item-product">
                            <div class="row-product">
                                <a class="link-row-product" href="<?php echo e(url('product/'.$cate_slug.'/' . $product->slug.'.html')); ?>">
                                    <div class="image-row-product">
                                        <img class="thumb-row-product" src="<?php echo e(asset($product->thumbnail)); ?>">
                                    </div>
                                    <h2 class="name-row-product"><?php echo e($product->name); ?></h2>
                                    <div class="price-row-product">
                                        <span
                                            class="sale-row-product"><?php echo e($product->sale_price); ?><sup>đ</sup></span><del><?php echo e($product->product_price); ?></del>
                                    </div>
                                    <span
                                        class="discount-row-product">-<?php echo e(100 - ($product->sale_price / $product->product_price) * 100); ?>%</span>
                                </a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/home.blade.php ENDPATH**/ ?>