

<?php $__env->startSection('content'); ?>
    <div class="home-product">
        <div class="container">
            <div class="list-blog">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-blog">
                        <a href="<?php echo e(url('blog/'.$blog->slug.'.html')); ?>">
                            <h2><?php echo e($blog->title); ?></h2>
                            <img src="<?php echo e(asset($blog->thumbnail)); ?>" alt="Not found">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/blog/showBlog.blade.php ENDPATH**/ ?>