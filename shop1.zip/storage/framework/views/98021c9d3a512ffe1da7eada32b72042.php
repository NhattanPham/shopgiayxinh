
<?php $__env->startSection('content'); ?>
    <div class="home-product">
        <div class="container">
            <div class="uk-grid">
                <div class="uk-width-1-1 uk-width-medium-4-10">
                    <div class="image-detail">
                        <?php $__currentLoopData = json_decode($product->product_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img style="width:100%" src="<?php echo e(asset('uploads/products/images/' . $image)); ?>" alt="Not found">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="list-image-detail">
                        <?php $__currentLoopData = json_decode($product->product_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img src="<?php echo e(asset('uploads/products/images/' . $image)); ?>" alt="Not found">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="uk-width-1-1 uk-width-medium-6-10">
                    <div class="product-name">
                        <h2><?php echo e($product->name); ?></h2>
                    </div>
                    <div class="product-price">
                        <span><?php echo e(number_format($product->sale_price, 0, ',', '.')); ?>đ</span>
                        <del><?php echo e(number_format($product->product_price, 0, ',', '.')); ?>đ</del>
                    </div>
                    <div class="product-intro">
                        <p><?php echo e($product->introtext); ?></p>
                    </div>
                    <div class="option option-color">
                        <div class="text-upcase">Chọn màu sắc: </div>
                        <div>
                            <ul>
                                <?php $__currentLoopData = json_decode($product->product_colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><button type="button" class="uk-button color button-choose-color"><?php echo e($color); ?></button></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="option option-size">
                        <div class="text-upcase">Chọn size: </div>
                        <div>
                            <ul>
                                <?php $__currentLoopData = json_decode($product->product_sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><button type="button" class="uk-button size button-choose"><?php echo e($size); ?></button></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="option option-quantity">
                        <div class="text-upcase">Số lượng: </div>
                        <div class="change-quantity">
                            <button type="button" class="uk-button" id="decrease-quantity">-</button>
                            <input type="number" id="quantityProduct" value="1">
                            <button type="button" class="uk-button" id="increase-quantity">+</button><br>
                            <div style="padding-top: 10px"><span>Còn hàng</span></div>
                        </div>
                    </div>
                    <form id="checkout" action="<?php echo e(url('/cart/addToCart/' . $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="option-button-list">
                            <div class="button-addtocart">
                                <button class="uk-button">Thêm vào giỏ hàng</button>
                            </div>
                            <div class="button-buy">
                                <button class="uk-button uk-button-danger" id="buyNow">Mua ngay</button>
                            </div>
                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="color" id="color" value="<?php echo e(json_decode($product->product_colors)[0]); ?>">
                            <input type="hidden" name="size" id="size" value="<?php echo e(json_decode($product->product_sizes)[0]); ?>">
                            <input type="hidden" name="quantity" id="quantityHidden" value="1">
                        </div>
                    </form>
                </div>
            </div>
            <div class="uk-grid product-description">
                <div class="title-description">
                    <span>CHI TIẾT SẢN PHẨM</span>
                </div>
                <div class="text-description">
                    <?php
                        echo html_entity_decode($product->description);
                    ?>
                </div>
            </div>
            <div class="product-similar">
                <h2>Sản phẩm tương tự</h2>
                <?php
                    $listProduct = App\Models\Product::where('cate_id', $product->cate_id)
                        ->take(4)
                        ->get();
                    // dd($listProduct);
                ?>
                <ul class="list-product-four">
                    <?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('frontend.partials.itemProduct', ['product' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            const inputQuantity = document.getElementById('quantityProduct');
            const quantityHidden = document.getElementById('quantityHidden');
            const increaseQuantity = document.getElementById('increase-quantity');
            const decreaseQuantity = document.getElementById('decrease-quantity');
            const buyNowBtn = document.getElementById('buyNow');
            var colorButtons = document.querySelectorAll('.color');
            var sizeButtons = document.querySelectorAll('.size');
            colorButtons.forEach(color => {
                color.addEventListener('click', function() {
                    $('.color').removeClass('button-choose-active');
                    var colorInput = document.getElementById('color');
                    colorInput.value = getTextButton(this);
                    this.classList.add('button-choose-active');
                })
            });
            sizeButtons.forEach(size => {
                size.addEventListener('click', function() {
                    $('.size').removeClass('button-choose-active');
                    var sizeInput = document.getElementById('size');
                    sizeInput.value = getTextButton(this);
                    this.classList.add('button-choose-active');
                })
            });

            function getTextButton(button) {
                return button.textContent;
            }

            increaseQuantity.addEventListener('click', function() {
                if (inputQuantity.value != 100) {
                    inputQuantity.value++;
                    quantityHidden.value++;
                }

            });
            decreaseQuantity.addEventListener('click', function() {
                if (inputQuantity.value != 1) {
                    inputQuantity.value--;
                    quantityHidden.value--;
                }

            });
            buyNowBtn.addEventListener('click',function(){
                const checkoutForm = document.getElementById('checkout');
                checkoutForm.action = "<?php echo e(url('/cart/addToCheckout')); ?>";
            })
            inputQuantity.addEventListener('input', function() {
                var value = parseInt(this.value);
                // console.log(value)

                quantityHidden.value = value;
                if (value < 1) {
                    this.value = 1;
                    quantityHidden.value = 1;
                } else if (value > 100) {
                    this.value = 100;
                    quantityHidden.value = 100;
                }

            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProject\shopgiayxinh\resources\views/frontend/product/showDetail.blade.php ENDPATH**/ ?>