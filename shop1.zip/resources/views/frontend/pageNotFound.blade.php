@extends('welcome')
@section('content')
<div style="padding: 50px 0 250px 100px;">
    <h2>Trang không tồn tại</h2>
</div>
@endsection