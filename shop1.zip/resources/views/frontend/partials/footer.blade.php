<footer class="footer">
    <div class="main-footer">
        <div class="container">
            <div class="row-main-footer">
                <div class="intro-footer">
                    <h3 class="title-footer">Xưởng Giày Dép</h3>
                    <ul class="list-contact">
                        <li class="hotline-footer">
                            <i class="icon-phone-footer"></i>
                            <span class="text-contact"><strong>Hotline:</strong> <span
                                    class="phone-contact">0909.57.80.85</span></span>
                        </li>
                        <li class="email-footer">
                            <i class="icon-email-footer"></i>
                            <span class="text-contact"><strong>Email:</strong> xuonggiaydep@gmail.com</span>
                        </li>
                        <li class="address-footer">
                            <i class="icon-address-footer"></i>
                            <span class="text-contact"><strong>Địa chỉ:</strong> 30 Đường T4B, Phường Tây Thạnh,
                                Quận Tân Phú, TP.HCM</span>
                        </li>
                    </ul>
                </div>
                <div class="menu-footer">
                    <h3 class="title-footer">Giới thiệu</h3>
                    <ul class="menu">
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                    </ul>
                </div>
                <div class="menu-footer">
                    <h3 class="title-footer">Hổ trợ</h3>
                    <ul class="menu">
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                        <li><a href="">Giới thiệu chung</a></li>
                    </ul>
                </div>
                <div class="social-footer">
                    <h3 class="title-footer">Facebook</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-right">
        <div class="container">
            <div class="text-copy-right">
                Bản quyền 2024 XuongGiayDep.VN
            </div>
        </div>
    </div>
</footer>

