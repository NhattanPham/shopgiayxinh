@extends('backend.master')
@section('title','Trang quản trị')
@section('content')
    <h1>This is dashboard</h1>
@endsection